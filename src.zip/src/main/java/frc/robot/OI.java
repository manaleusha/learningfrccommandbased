package frc.robot;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.XboxController.Button;
import frc.robot.subsystems.RobotMap;

public class OI {
    private Joystick driverController = new JoystickController(RobotMap.DRIVER_CONTROLLER);
    Button xButton=new JoystickButton(driverController, RobotMap.BUTTON_X);
//would like to know the value of the y-axis on left or right side so use double to return the value.
public double GetRawAxis(int axis){
return driverController.getRawAxis(axis);
} 


public OI() {
    xButton.whenPressed(new move(2, 0.5, 0.5));
    

}

}
