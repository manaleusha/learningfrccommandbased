// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.subsystems;

import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.can.TalonSRX;

import edu.wpi.first.wpilibj.command.Subsystem;
import frc.robot.commands.TankDriver;

/** Add your docs here. */
public class DriveTrain extends Subsystem {
  private TalonSRX motorL1 = new TalonSRX(RobotMap.Motor_L1);
  private TalonSRX motorL2 = new TalonSRX(RobotMap.Motor_L2);
  private TalonSRX motorR1 = new TalonSRX(RobotMap.Motor_R1);
  private TalonSRX motorR2 = new TalonSRX(RobotMap.Motor_R2);

  @Override
  public void initDefaultCommand() {
    // Set the default command for a subsystem here.
    setDefaultCommand(new TankDriver());
    
  }
//method created for coding for the speed of the motors when riding it. this method
//will let the motors controlling left wheels access this method absolutely.
public void setLeftMotors(double speed) {
  motorL1.set(ControlMode.PercentOutput, -speed);
  motorL2.set(ControlMode.PercentOutput, -speed);
}

//a method for controlling the right motors 
public void setRightMotors(double speed) {
  motorR1.set(ControlMode.PercentOutput, speed);
  motorR2.set(ControlMode.PercentOutput, speed);
}



}
