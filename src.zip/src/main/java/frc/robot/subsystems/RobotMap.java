package frc.robot.subsystems;

public class RobotMap {

	public static final int Motor_L1 = 0;
	public static final int Motor_L2 = 1;
	public static final int Motor_R1 = 2;
	public static final int Motor_R2 = 3;
	public static final String DRIVER_CONTROLLER = 0;
	public static final String L_STICK_Y = 1;
	public static final String R_STICK_Y = 5;
	

}
